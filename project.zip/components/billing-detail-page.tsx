"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/components/auth-context";
import { toast } from "react-hot-toast";
import {
  ArrowLeft,
  Plus,
  Loader2,
  CreditCard,
  FileText,
  DollarSign,
  User,
  Phone,
  Calendar,
  PieChart as PieChartIcon,
  ChevronRight,
} from "lucide-react";
import { AddDebtModal } from "@/components/add-debt-modal";
import { AddPaymentModal } from "@/components/add-payment-modal";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Legend,
  Tooltip,
} from "recharts";
import { PaymentHistory } from "./payment-history";
import { BillingChart } from "./billing-chart";

export function BillingDetailPage({ patient, onBack }: any) {
  const { token } = useAuth();
  const [billings, setBillings] = useState([]);
  const [stats, setStats] = useState({
    totalPaid: 0,
    totalDebt: 0,
    remainingBalance: 0,
  });
  const [loading, setLoading] = useState(false);
  const [showAddDebt, setShowAddDebt] = useState(false);
  const [showAddPayment, setShowAddPayment] = useState(false);

  useEffect(() => {
    if (patient?.patientId) {
      fetchTransactions();
    }
  }, [token, patient?.patientId]);

  const fetchTransactions = async () => {
    if (!patient?.patientId) {
      console.error("[v0] No patientId available");
      return;
    }

    setLoading(true);
    try {
      console.log("[v0] Fetching transactions for patient:", patient.patientId);
      const res = await fetch(
        `/api/billing/${patient.patientId}/transactions`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (res.ok) {
        const data = await res.json();
        console.log("[v0] Received billing data:", data);
        setBillings(data.billings || []);
        setStats(
          data.stats || { totalPaid: 0, totalDebt: 0, remainingBalance: 0 }
        );
      } else {
        const errorData = await res.json();
        console.error("[v0] Failed to fetch transactions:", errorData);
        toast.error("Failed to load billing data");
      }
    } catch (error) {
      console.error("[v0] Failed to fetch transactions:", error);
      toast.error("Failed to load billing data");
    } finally {
      setLoading(false);
    }
  };

  const handleDebtAdded = () => {
    setShowAddDebt(false);
    fetchTransactions();
    toast.success("Debt added successfully");
  };

  const handlePaymentAdded = () => {
    setShowAddPayment(false);
    fetchTransactions();
    toast.success("Payment recorded successfully");
  };

  return (
    <div className="min-h-screen bg-background">
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8">
        {/* Header with Back and Action Buttons */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <button
              onClick={onBack}
              className="group flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors duration-200 font-medium w-fit cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5 transition-transform group-hover:-translate-x-0.5 duration-200" />
              Back to Patients
            </button>

            {/* Action Buttons in Header */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowAddDebt(true)}
                className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground px-4 py-2.5 rounded-lg transition-all duration-200 font-medium shadow-sm hover:shadow-md active:scale-95 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Add Debt
              </button>
              <button
                onClick={() => setShowAddPayment(true)}
                className="flex items-center gap-2 bg-accent hover:bg-accent/90 text-accent-foreground px-4 py-2.5 rounded-lg transition-all duration-200 font-medium shadow-sm hover:shadow-md active:scale-95 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Add Payment
              </button>
            </div>
          </div>

          {/* Patient Header */}
          <div className="bg-card rounded-xl border border-border p-6 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="p-3 bg-primary/10 rounded-lg">
                <User className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
                  {patient?.name || "Unknown Patient"}
                </h1>
                <div className="flex flex-wrap items-center gap-3 mt-2">
                  <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                    <Phone className="w-3.5 h-3.5" />
                    {patient?.phone || "No phone"}
                  </div>
                  <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                    <span className="text-xs font-medium px-2 py-1 bg-muted rounded">
                      ID: {patient?.patientId || "N/A"}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Loading State */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 bg-card rounded-xl border border-border">
            <Loader2 className="w-12 h-12 text-primary animate-spin mb-4" />
            <p className="text-muted-foreground font-medium">
              Loading billing information...
            </p>
          </div>
        ) : (
          <>
            {/* Chart and Stats */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
              {/* Chart Section */}
              <div className="lg:col-span-2">
                <BillingChart stats={stats} />
              </div>

              {/* Stats Cards */}
              <div className="space-y-4">
                <div className="bg-card rounded-xl border border-border p-5 hover:border-primary/50 transition-colors duration-200">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-accent/10 rounded-lg">
                        <DollarSign className="w-5 h-5 text-accent" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">
                          Total Paid
                        </p>
                        <p className="text-2xl font-bold text-accent">
                          ${(stats?.totalPaid || 0).toFixed(2)}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-accent rounded-full transition-all duration-700 ease-out"
                      style={{
                        width: `${
                          stats?.totalDebt
                            ? Math.min(
                                100,
                                (stats.totalPaid / stats.totalDebt) * 100
                              )
                            : 0
                        }%`,
                      }}
                    ></div>
                  </div>
                </div>

                <div className="bg-card rounded-xl border border-border p-5 hover:border-primary/50 transition-colors duration-200">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <FileText className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">
                          Total Debt
                        </p>
                        <p className="text-2xl font-bold text-foreground">
                          ${(stats?.totalDebt || 0).toFixed(2)}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div
                  className={`bg-card rounded-xl border p-5 hover:border-primary/50 transition-colors duration-200 ${
                    (stats?.remainingBalance || 0) > 0
                      ? "border-destructive/20"
                      : "border-accent/20"
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div
                        className={`p-2 rounded-lg ${
                          (stats?.remainingBalance || 0) > 0
                            ? "bg-destructive/10"
                            : "bg-accent/10"
                        }`}
                      >
                        <CreditCard
                          className={`w-5 h-5 ${
                            (stats?.remainingBalance || 0) > 0
                              ? "text-destructive"
                              : "text-accent"
                          }`}
                        />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">
                          Remaining Balance
                        </p>
                        <p
                          className={`text-2xl font-bold ${
                            (stats?.remainingBalance || 0) > 0
                              ? "text-destructive"
                              : "text-accent"
                          }`}
                        >
                          ${(stats?.remainingBalance || 0).toFixed(2)}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-700 ease-out ${
                        (stats?.remainingBalance || 0) > 0
                          ? "bg-destructive"
                          : "bg-accent"
                      }`}
                      style={{
                        width: `${
                          stats?.totalDebt
                            ? Math.min(
                                100,
                                (Math.abs(stats.remainingBalance) /
                                  stats.totalDebt) *
                                  100
                              )
                            : 0
                        }%`,
                      }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Payment History */}
            <div className="bg-card rounded-xl border border-border shadow-sm">
              <PaymentHistory billings={billings} patient={patient} />
            </div>
          </>
        )}

        {/* Modals */}
        {patient?.patientId && (
          <>
            <AddDebtModal
              patientId={patient.patientId}
              isOpen={showAddDebt}
              onClose={() => setShowAddDebt(false)}
              onSuccess={handleDebtAdded}
            />
            <AddPaymentModal
              patientId={patient.patientId}
              remainingBalance={stats?.remainingBalance || 0}
              isOpen={showAddPayment}
              onClose={() => setShowAddPayment(false)}
              onSuccess={handlePaymentAdded}
            />
          </>
        )}
      </main>
    </div>
  );
}
