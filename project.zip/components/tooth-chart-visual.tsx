"use client"

interface ToothStatus {
  status: string
  notes?: string
}

interface ToothChartProps {
  teeth: Record<number, ToothStatus>
  onToothClick: (toothNumber: number) => void
  readOnly?: boolean
}

export function ToothChartVisual({ teeth, onToothClick, readOnly = false }: ToothChartProps) {
  const getToothColor = (status: string) => {
    const colors: Record<string, string> = {
      healthy: "#10b981",
      cavity: "#ef4444",
      missing: "#9ca3af",
      treated: "#3b82f6",
      root_canal: "#f97316",
      crown: "#8b5cf6",
    }
    return colors[status] || "#3b82f6"
  }

  const getToothShape = (toothNumber: number) => {
    // Tooth numbers 1-8: upper right, 9-16: upper left, 17-24: lower left, 25-32: lower right
    const isIncisor = [6, 7, 8, 9, 10, 11, 22, 23, 24, 25, 26, 27].includes(toothNumber)
    const isCanine = [5, 12, 21, 28].includes(toothNumber)
    const isPremolar = [4, 5, 13, 20, 29, 30].includes(toothNumber)
    const isMolar = [1, 2, 3, 14, 15, 16, 17, 18, 19, 31, 32].includes(toothNumber)

    if (isIncisor) return "rounded-t-lg rounded-b-sm"
    if (isCanine) return "rounded-t-lg rounded-b-sm"
    if (isPremolar) return "rounded-lg"
    return "rounded-lg"
  }

  return (
    <div className="space-y-6">
      {/* Upper Teeth */}
      <div>
        <h3 className="font-semibold text-foreground mb-3 text-sm">Upper Teeth</h3>
        <div className="grid grid-cols-8 gap-2">
          {Array.from({ length: 16 }, (_, i) => i + 1).map((toothNum) => (
            <button
              key={toothNum}
              onClick={() => !readOnly && onToothClick(toothNum)}
              disabled={readOnly}
              className={`aspect-square rounded-lg border-2 border-border flex items-center justify-center font-bold text-xs transition-all ${
                readOnly ? "cursor-default" : "hover:opacity-80 cursor-pointer"
              }`}
              style={{
                backgroundColor: getToothColor(teeth[toothNum]?.status || "healthy"),
                color: "white",
              }}
              title={teeth[toothNum]?.status || "healthy"}
            >
              {toothNum}
            </button>
          ))}
        </div>
      </div>

      {/* Lower Teeth */}
      <div>
        <h3 className="font-semibold text-foreground mb-3 text-sm">Lower Teeth</h3>
        <div className="grid grid-cols-8 gap-2">
          {Array.from({ length: 16 }, (_, i) => i + 17).map((toothNum) => (
            <button
              key={toothNum}
              onClick={() => !readOnly && onToothClick(toothNum)}
              disabled={readOnly}
              className={`aspect-square rounded-lg border-2 border-border flex items-center justify-center font-bold text-xs transition-all ${
                readOnly ? "cursor-default" : "hover:opacity-80 cursor-pointer"
              }`}
              style={{
                backgroundColor: getToothColor(teeth[toothNum]?.status || "healthy"),
                color: "white",
              }}
              title={teeth[toothNum]?.status || "healthy"}
            >
              {toothNum}
            </button>
          ))}
        </div>
      </div>

      {/* Legend */}
      <div className="p-4 bg-muted rounded-lg">
        <h3 className="font-semibold text-foreground mb-3 text-sm">Tooth Status Legend</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded" style={{ backgroundColor: getToothColor("healthy") }} />
            <span className="text-foreground">Healthy</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded" style={{ backgroundColor: getToothColor("cavity") }} />
            <span className="text-foreground">Cavity</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded" style={{ backgroundColor: getToothColor("missing") }} />
            <span className="text-foreground">Missing</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded" style={{ backgroundColor: getToothColor("treated") }} />
            <span className="text-foreground">Treated</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded" style={{ backgroundColor: getToothColor("root_canal") }} />
            <span className="text-foreground">Root Canal</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded" style={{ backgroundColor: getToothColor("crown") }} />
            <span className="text-foreground">Crown</span>
          </div>
        </div>
      </div>
    </div>
  )
}
