//@ts-nocheck
import { type NextRequest, NextResponse } from "next/server"
import { ToothChart, connectDB } from "@/lib/db-server"
import { verifyToken } from "@/lib/auth"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectDB()
    const token = request.headers.get("authorization")?.split(" ")[1]
    if (!token) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    const payload = verifyToken(token)
    if (!payload) return NextResponse.json({ error: "Invalid token" }, { status: 401 })

    const chart = await ToothChart.findById(params.id)
    if (!chart) return NextResponse.json({ error: "Tooth chart not found" }, { status: 404 })

    return NextResponse.json({ success: true, chart })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: "Failed to fetch tooth chart" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectDB()
    const token = request.headers.get("authorization")?.split(" ")[1]
    if (!token) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    const payload = verifyToken(token)
    if (!payload) return NextResponse.json({ error: "Invalid token" }, { status: 401 })

    const chart = await ToothChart.findById(params.id)
    if (!chart) return NextResponse.json({ error: "Tooth chart not found" }, { status: 404 })

    if (payload.role === "doctor") {
      // Verify the doctor has access to this patient
      const { Patient } = await import("@/lib/db-server")
      const patient = await Patient.findById(chart.patientId)
      if (!patient) return NextResponse.json({ error: "Patient not found" }, { status: 404 })
    }

    const { teeth, procedures, overallNotes } = await request.json()

    // Validate procedures array if provided
    if (procedures && Array.isArray(procedures)) {
      chart.procedures = procedures
    }

    // Update other fields
    if (teeth) {
      chart.teeth = teeth
    }
    if (overallNotes !== undefined) {
      chart.overallNotes = overallNotes
    }

    chart.lastReview = new Date()
    chart.doctorId = payload.userId
    await chart.save()

    return NextResponse.json({ success: true, chart })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: "Failed to update tooth chart" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectDB()
    const token = request.headers.get("authorization")?.split(" ")[1]
    if (!token) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    const payload = verifyToken(token)
    if (!payload) return NextResponse.json({ error: "Invalid token" }, { status: 401 })

    if (payload.role === "receptionist" || payload.role === "patient") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    const chart = await ToothChart.findById(params.id)
    if (!chart) return NextResponse.json({ error: "Tooth chart not found" }, { status: 404 })

    await ToothChart.findByIdAndDelete(params.id)

    return NextResponse.json({ success: true, message: "Tooth chart deleted successfully" })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: "Failed to delete tooth chart" }, { status: 500 })
  }
}
