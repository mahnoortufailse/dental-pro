import { type NextRequest, NextResponse } from "next/server"
import { Appointment, connectDB, User, Patient } from "@/lib/db"
import { verifyToken, verifyPatientToken } from "@/lib/auth"
import { sendAppointmentConfirmation } from "@/lib/whatsapp-service"
import { validateAppointmentScheduling } from "@/lib/appointment-validation"
import { sendAppointmentConfirmationEmail } from "@/lib/nodemailer-service"

export async function GET(request: NextRequest) {
  try {
    await connectDB()
    const token = request.headers.get("authorization")?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const payload = verifyToken(token)
    let patientId: string | null = null

    if (!payload) {
      // Try patient token
      patientId = verifyPatientToken(token)
      if (!patientId) {
        return NextResponse.json({ error: "Invalid token" }, { status: 401 })
      }
    }

    const query: any = {}

    if (payload?.role === "doctor") {
      // For doctors, show only their appointments
      query.doctorId = String(payload.userId)
      console.log("  Doctor fetching appointments - doctorId:", query.doctorId)
    } else if (patientId) {
      // For patients, show only their appointments
      query.patientId = patientId
      console.log("  Patient fetching appointments - patientId:", patientId)
    }
    // For admin and receptionist, show all appointments

    const appointments = await Appointment.find(query).sort({
      date: -1,
      time: -1,
    })

    console.log("  Found appointments:", appointments.length, "for query:", query)

    return NextResponse.json({
      success: true,
      appointments: appointments.map((apt) => ({
        _id: apt._id.toString(),
        id: apt._id.toString(),
        patientId: apt.patientId,
        patientName: apt.patientName,
        doctorId: apt.doctorId,
        doctorName: apt.doctorName,
        date: apt.date,
        time: apt.time,
        type: apt.type,
        status: apt.status,
        roomNumber: apt.roomNumber,
        duration: apt.duration,
      })),
    })
  } catch (error) {
    console.error("  Get appointments error:", error)
    return NextResponse.json({ error: "Failed to fetch appointments" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    await connectDB()
    console.log("[DEBUG] Database connected")

    const token = request.headers.get("authorization")?.split(" ")[1]
    console.log("[DEBUG] Token received:", token ? "Yes" : "No")

    if (!token) {
      console.warn("[DEBUG] No token found")
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const payload = verifyToken(token)
    console.log("[DEBUG] Token payload:", payload)

    if (!payload) {
      console.warn("[DEBUG] Invalid token")
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    const { patientId, patientName, doctorId, doctorName, date, time, type, roomNumber, duration } =
      await request.json()
    console.log("[DEBUG] Appointment data:", {
      patientId,
      patientName,
      doctorId,
      doctorName,
      date,
      time,
      type,
    })

    const finalDoctorId = String(doctorId).trim()
    if (!finalDoctorId) {
      console.warn("[DEBUG] Doctor ID is missing")
      return NextResponse.json({ error: "Doctor ID is required" }, { status: 400 })
    }

    if (!patientId || !String(patientId).trim()) {
      console.warn("[DEBUG] Patient ID is missing")
      return NextResponse.json({ error: "Patient ID is required" }, { status: 400 })
    }

    let doctor = null
    try {
      doctor = await User.findById(finalDoctorId)
    } catch (err) {
      console.warn("[DEBUG] Error finding doctor with ID:", finalDoctorId, err)
      // Try to find by email or other fields if ObjectId lookup fails
      doctor = null
    }

    console.log("[DEBUG] Doctor found:", doctor ? doctor.name : "No doctor found")

    if (!doctor) {
      console.warn("[DEBUG] Doctor not found with ID:", finalDoctorId)
      return NextResponse.json({ error: "Doctor not found" }, { status: 404 })
    }

    const validation = await validateAppointmentScheduling(finalDoctorId, date, time, duration || 30)
    if (!validation.isValid) {
      console.warn("[DEBUG] Validation failed:", validation.error)
      return NextResponse.json({ error: validation.error }, { status: 409 })
    }

    const newAppointment = await Appointment.create({
      patientId,
      patientName,
      doctorId: finalDoctorId,
      doctorName,
      date,
      time,
      type,
      status: "confirmed",
      roomNumber,
      duration: duration || 30,
    })
    console.log("[DEBUG] Appointment created:", newAppointment._id.toString())

    console.log("[DEBUG] Looking up patient with ID:", patientId)

    // Fetch patient phone number from Patient collection
    const patient = await Patient.findById(patientId)

    console.log("[DEBUG] Patient found:", patient ? patient.name : "No patient found")
    console.log("[DEBUG] Patient phone:", patient?.phone)

    if (patient && patient.phone) {
      const appointmentId = newAppointment._id.toString()
      console.log("[DEBUG] Sending WhatsApp confirmation for:", {
        to: patient?.phone,
        patientName,
        type,
        date,
        time,
        doctorName,
        appointmentId,
      })

      const whatsappResult = await sendAppointmentConfirmation(
        patient?.phone,
        patientName,
        type || "Appointment",
        date,
        time,
        doctorName,
        appointmentId,
      )

      console.log("[DEBUG] WhatsApp result:", whatsappResult)

      if (!whatsappResult.success) {
        console.warn("  WhatsApp notification failed for appointment creation:", whatsappResult.error)
      } else {
        console.log("  WhatsApp appointment confirmation sent:", whatsappResult.messageId)
      }
    } else {
      console.warn("[DEBUG] Patient phone missing — WhatsApp message skipped")
    }

    if (patient && patient.email) {
      console.log("  Sending email confirmation to patient:", patient.email)
      const emailResult = await sendAppointmentConfirmationEmail(
        patient.email,
        patientName,
        doctorName,
        date,
        time,
        type || "Appointment",
      )

      if (!emailResult.success) {
        console.warn("  Email notification failed for appointment creation:", emailResult.error)
      } else {
        console.log("  Email appointment confirmation sent:", emailResult.messageId)
      }
    } else {
      console.warn("  Patient email missing — Email message skipped")
    }

    return NextResponse.json({
      success: true,
      appointment: {
        _id: newAppointment._id.toString(),
        id: newAppointment._id.toString(),
        patientId: newAppointment.patientId,
        patientName: newAppointment.patientName,
        doctorId: newAppointment.doctorId,
        doctorName: newAppointment.doctorName,
        date: newAppointment.date,
        time: newAppointment.time,
        type: newAppointment.type,
        status: newAppointment.status,
        roomNumber: newAppointment.roomNumber,
        duration: newAppointment.duration,
      },
    })
  } catch (error) {
    console.error("  Add appointment error:", error)
    return NextResponse.json({ error: "Failed to create appointment" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    await connectDB()
    console.log("[DEBUG] Database connected")

    const token = request.headers.get("authorization")?.split(" ")[1]
    console.log("[DEBUG] Token received:", token ? "Yes" : "No")

    if (!token) {
      console.warn("[DEBUG] No token found")
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const payload = verifyToken(token)
    console.log("[DEBUG] Token payload:", payload)

    if (!payload) {
      console.warn("[DEBUG] Invalid token")
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    const { appointmentId, patientId, patientName, doctorId, doctorName, date, time, type, roomNumber, duration } =
      await request.json()
    console.log("[DEBUG] Appointment data:", {
      appointmentId,
      patientId,
      patientName,
      doctorId,
      doctorName,
      date,
      time,
      type,
    })

    if (!appointmentId || !String(appointmentId).trim()) {
      console.warn("[DEBUG] Appointment ID is missing")
      return NextResponse.json({ error: "Appointment ID is required" }, { status: 400 })
    }

    const appointment = await Appointment.findById(appointmentId)
    console.log("[DEBUG] Appointment found:", appointment ? appointment._id.toString() : "No appointment found")

    if (!appointment) {
      console.warn("[DEBUG] Appointment not found with ID:", appointmentId)
      return NextResponse.json({ error: "Appointment not found" }, { status: 404 })
    }

    if (payload?.role === "doctor" && appointment.doctorId !== payload.userId) {
      console.warn("[DEBUG] Doctor trying to edit another doctor's appointment")
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const updatedAppointment = await Appointment.findByIdAndUpdate(
      appointmentId,
      {
        patientId,
        patientName,
        doctorId: String(doctorId), // Convert doctorId to string
        doctorName,
        date,
        time,
        type,
        roomNumber,
        duration: duration || 30,
      },
      { new: true },
    )
    console.log("[DEBUG] Appointment updated:", updatedAppointment._id.toString())

    return NextResponse.json({
      success: true,
      appointment: {
        _id: updatedAppointment._id.toString(),
        id: updatedAppointment._id.toString(),
        patientId: updatedAppointment.patientId,
        patientName: updatedAppointment.patientName,
        doctorId: updatedAppointment.doctorId,
        doctorName: updatedAppointment.doctorName,
        date: updatedAppointment.date,
        time: updatedAppointment.time,
        type: updatedAppointment.type,
        status: updatedAppointment.status,
        roomNumber: updatedAppointment.roomNumber,
        duration: updatedAppointment.duration,
      },
    })
  } catch (error) {
    console.error("  Update appointment error:", error)
    return NextResponse.json({ error: "Failed to update appointment" }, { status: 500 })
  }
}
