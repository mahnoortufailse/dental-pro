import { type NextRequest, NextResponse } from "next/server"
import { AppointmentReport, connectDB } from "@/lib/db"
import { verifyToken } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    await connectDB()
    const token = request.headers.get("authorization")?.split(" ")[1]
    if (!token) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    const payload = verifyToken(token)
    if (!payload) return NextResponse.json({ error: "Invalid token" }, { status: 401 })

    const { searchParams } = new URL(request.url)
    const appointmentId = searchParams.get("appointmentId")

    if (!appointmentId) {
      return NextResponse.json({ error: "Appointment ID required" }, { status: 400 })
    }

    const report = await AppointmentReport.findOne({ appointmentId })
      .populate("patientId", "name")
      .populate("doctorId", "name specialty")

    return NextResponse.json({ success: true, report })
  } catch (error) {
    console.error("[v0] GET appointment report error:", error)
    return NextResponse.json({ error: "Failed to fetch report" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    await connectDB()
    const token = request.headers.get("authorization")?.split(" ")[1]
    if (!token) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    const payload = verifyToken(token)
    if (!payload) return NextResponse.json({ error: "Invalid token" }, { status: 401 })

    if (payload.role !== "doctor") {
      return NextResponse.json({ error: "Only doctors can create reports" }, { status: 403 })
    }

    const { appointmentId, patientId, procedures, findings, notes, nextVisit, followUpDetails } = await request.json()

    if (!appointmentId || !patientId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const report = await AppointmentReport.create({
      appointmentId,
      patientId,
      doctorId: payload.userId,
      procedures,
      findings,
      notes,
      nextVisit,
      followUpDetails,
    })

    await report.populate("patientId", "name").populate("doctorId", "name specialty")
    return NextResponse.json({ success: true, report })
  } catch (error) {
    console.error("[v0] POST appointment report error:", error)
    return NextResponse.json({ error: "Failed to create report" }, { status: 500 })
  }
}
