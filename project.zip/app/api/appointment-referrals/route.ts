//@ts-nocheck
import { type NextRequest, NextResponse } from "next/server"
import { AppointmentReferral, connectDB, Appointment, User } from "@/lib/db-server"
import { verifyToken } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    await connectDB()
    const token = request.headers.get("authorization")?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload || payload.role !== "doctor") {
      return NextResponse.json({ error: "Only doctors can view referral requests" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const filterType = searchParams.get("type") || "all" // "received", "sent", or "all"

    const query: any = {}

    if (filterType === "received") {
      query.toDoctorId = payload.userId
    } else if (filterType === "sent") {
      query.fromDoctorId = payload.userId
    } else if (filterType === "all") {
      query.$or = [{ toDoctorId: payload.userId }, { fromDoctorId: payload.userId }]
    }

    const referrals = await AppointmentReferral.find(query).sort({ createdAt: -1 })

    return NextResponse.json({ success: true, referrals })
  } catch (error) {
    console.error("GET appointment referrals error:", error)
    return NextResponse.json({ error: "Failed to fetch referrals" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    await connectDB()
    const token = request.headers.get("authorization")?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload || payload.role !== "doctor") {
      return NextResponse.json({ error: "Only doctors can create referrals" }, { status: 403 })
    }

    const { appointmentId, toDoctorId, referralReason } = await request.json()

    if (!appointmentId) {
      return NextResponse.json({ error: "Appointment ID is required" }, { status: 400 })
    }

    if (!toDoctorId) {
      return NextResponse.json({ error: "Target doctor is required" }, { status: 400 })
    }

    if (!referralReason || !String(referralReason).trim()) {
      return NextResponse.json({ error: "Referral reason is required" }, { status: 400 })
    }

    // Get appointment details
    const appointment = await Appointment.findById(appointmentId)
    if (!appointment) {
      return NextResponse.json({ error: "Appointment not found" }, { status: 404 })
    }

    // Verify the requesting doctor owns this appointment
    if (appointment.doctorId !== payload.userId) {
      return NextResponse.json({ error: "You can only refer your own appointments" }, { status: 403 })
    }

    if (appointment.isReferred) {
      return NextResponse.json({ error: "This appointment is already referred to another doctor" }, { status: 400 })
    }

    // Get target doctor info
    const targetDoctor = await User.findById(toDoctorId)
    if (!targetDoctor) {
      return NextResponse.json({ error: "Target doctor not found" }, { status: 404 })
    }

    // Create referral record
    const referral = await AppointmentReferral.create({
      appointmentId,
      patientId: appointment.patientId,
      patientName: appointment.patientName,
      fromDoctorId: payload.userId,
      fromDoctorName: payload.name || "Unknown",
      toDoctorId: String(toDoctorId),
      toDoctorName: targetDoctor.name,
      referralReason: String(referralReason).trim(),
      status: "pending",
      notes: "",
    })

    await Appointment.findByIdAndUpdate(appointmentId, {
      originalDoctorId: appointment.doctorId,
      originalDoctorName: appointment.doctorName,
      isReferred: true,
      currentReferralId: referral._id,
    })

    return NextResponse.json({ success: true, referral })
  } catch (error) {
    console.error("POST appointment referral error:", error)
    return NextResponse.json({ error: "Failed to create referral" }, { status: 500 })
  }
}
