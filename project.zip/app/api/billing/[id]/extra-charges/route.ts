import { type NextRequest, NextResponse } from "next/server"
import { verifyToken } from "@/lib/auth"
import { connectDB, Billing, Patient } from "@/lib/db-server"
import mongoose from "mongoose"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const authHeader = request.headers.get("Authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const payload = verifyToken(token)
    if (!payload) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Only doctors can request charges
    if (payload.role !== "doctor") {
      return NextResponse.json({ error: "Only doctors can request charges" }, { status: 403 })
    }

    const { id } = params
    const body = await request.json()
    const { amount, treatment, reason, patientName } = body

    if (!amount || !treatment) {
      return NextResponse.json({ error: "Amount and treatment are required" }, { status: 400 })
    }

    await connectDB()

    // Get patient to ensure it exists
    const patient = await Patient.findById(new mongoose.Types.ObjectId(id))
    if (!patient) {
      return NextResponse.json({ error: "Patient not found" }, { status: 404 })
    }

    // Create or update billing record with extra charges request
    const result = await Billing.findOneAndUpdate(
      { patientId: new mongoose.Types.ObjectId(id) },
      {
        $addToSet: {
          extraChargesRequested: {
            _id: new mongoose.Types.ObjectId(),
            amount: Number.parseFloat(amount as string),
            treatment,
            reason: reason || "",
            requestedBy: payload.userId,
            status: "pending",
            createdAt: new Date(),
          },
        },
      },
      { new: true, upsert: false },
    )

    // If no billing record exists, create one
    if (!result) {
      await Billing.create({
        patientId: new mongoose.Types.ObjectId(id),
        patientName: patientName || patient.name,
        totalAmount: 0,
        paidAmount: 0,
        paymentStatus: "Pending",
        paymentSplits: [],
        extraChargesRequested: [
          {
            _id: new mongoose.Types.ObjectId(),
            amount: Number.parseFloat(amount as string),
            treatment,
            reason: reason || "",
            requestedBy: payload.userId,
            status: "pending",
            createdAt: new Date(),
          },
        ],
        createdAt: new Date(),
        updatedAt: new Date(),
      })
    }

    return NextResponse.json({
      success: true,
      message: "Extra charges request sent for approval",
    })
  } catch (error) {
    console.error("[v0] Extra charges request error:", error)
    return NextResponse.json({ error: "Failed to process request" }, { status: 500 })
  }
}
