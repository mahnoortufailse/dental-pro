import { connectDB } from "@/lib/db-server"
import { Billing } from "@/lib/db-server"
import { verifyToken } from "@/lib/auth"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(req: NextRequest) {
  try {
    const token = req.headers.get("authorization")?.split(" ")[1]
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    // Only admin and receptionist can view billing requests
    if (!["admin", "receptionist"].includes(payload.role)) {
      return NextResponse.json({ error: "Only admin and receptionist can view billing requests" }, { status: 403 })
    }

    await connectDB()

    const { searchParams } = new URL(req.url)
    const status = searchParams.get("status") || "pending"

    // Get all billings with extra charges requests
    const query: any = {
      "extraChargesRequested.status": status,
    }

    const requests = await Billing.find(query)
      .populate("patientId", "name")
      .sort({ "extraChargesRequested.requestedAt": -1 })

    const formattedRequests = requests.map((billing: any) => ({
      _id: billing._id,
      billingId: billing._id.toString(),
      patientId: billing.patientId,
      patientName: billing.patientId?.name || "Unknown Patient",
      doctorName: billing.extraChargesRequested?.requestedBy || "Unknown Doctor",
      extraChargesRequested: billing.extraChargesRequested,
      totalAmount: billing.totalAmount,
    }))

    return NextResponse.json({ requests: formattedRequests })
  } catch (error) {
    console.error("[v0] Error fetching billing requests:", error)
    return NextResponse.json({ error: "Failed to fetch billing requests" }, { status: 500 })
  }
}
