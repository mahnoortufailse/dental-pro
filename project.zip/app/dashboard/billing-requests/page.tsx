//@ts-nocheck
"use client"

import { ProtectedRoute } from "@/components/protected-route"
import { Sidebar } from "@/components/sidebar"
import { useAuth } from "@/components/auth-context"
import { useState, useEffect } from "react"
import { toast } from "react-hot-toast"
import { Check, X, Loader2, Search, ChevronLeft, ChevronRight, Clock, CheckCircle, XCircle } from "lucide-react"

export default function BillingRequestsPage() {
  const { user, token } = useAuth()
  const [requests, setRequests] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage, setItemsPerPage] = useState(10)
  const [loading, setLoading] = useState({
    requests: false,
    approve: false,
    reject: false,
  })
  const [selectedRequest, setSelectedRequest] = useState(null)
  const [processingId, setProcessingId] = useState(null)
  const [statusFilter, setStatusFilter] = useState("pending")

  useEffect(() => {
    if (token) {
      fetchBillingRequests()
    }
  }, [token])

  const fetchBillingRequests = async () => {
    setLoading((prev) => ({ ...prev, requests: true }))
    try {
      const res = await fetch(`/api/billing/requests?status=${statusFilter}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      if (res.ok) {
        const data = await res.json()
        setRequests(data.requests || [])
      } else {
        const error = await res.json().catch(() => ({}))
        toast.error(error.error || "Failed to fetch billing requests")
      }
    } catch (error) {
      toast.error("Error fetching billing requests")
    } finally {
      setLoading((prev) => ({ ...prev, requests: false }))
    }
  }

  const handleApprove = async (billingId: string) => {
    setProcessingId(billingId)
    setLoading((prev) => ({ ...prev, approve: true }))
    try {
      const res = await fetch(`/api/billing/${billingId}/extra-charges`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ action: "approve" }),
      })

      if (res.ok) {
        toast.success("Extra charges approved and added to bill")
        await fetchBillingRequests()
      } else {
        const error = await res.json().catch(() => ({}))
        toast.error(error.error || "Failed to approve charges")
      }
    } catch (error) {
      toast.error("Error approving charges")
    } finally {
      setProcessingId(null)
      setLoading((prev) => ({ ...prev, approve: false }))
    }
  }

  const handleReject = async (billingId: string) => {
    setProcessingId(billingId)
    setLoading((prev) => ({ ...prev, reject: true }))
    try {
      const res = await fetch(`/api/billing/${billingId}/extra-charges`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ action: "reject" }),
      })

      if (res.ok) {
        toast.success("Extra charges request rejected")
        await fetchBillingRequests()
      } else {
        const error = await res.json().catch(() => ({}))
        toast.error(error.error || "Failed to reject charges")
      }
    } catch (error) {
      toast.error("Error rejecting charges")
    } finally {
      setProcessingId(null)
      setLoading((prev) => ({ ...prev, reject: false }))
    }
  }

  const filteredRequests = requests.filter((request) => {
    if (!searchTerm) return true
    const searchLower = searchTerm.toLowerCase()
    return (
      request.patientName?.toLowerCase().includes(searchLower) ||
      request.doctorName?.toLowerCase().includes(searchLower) ||
      request.billingId?.toLowerCase().includes(searchLower) ||
      request.extraChargesRequested?.reason?.toLowerCase().includes(searchLower)
    )
  })

  const totalPages = Math.ceil(filteredRequests.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const currentRequests = filteredRequests.slice(startIndex, endIndex)

  useEffect(() => {
    setCurrentPage(1)
  }, [searchTerm, statusFilter])

  return (
    <ProtectedRoute requiredRoles={["admin", "receptionist"]}>
      <div className="flex h-screen bg-background">
        <Sidebar />
        <main className="flex-1 overflow-auto md:pt-0 pt-16">
          <div className="p-4 sm:p-6 lg:p-8">
            <div className="mb-8">
              <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Billing Requests</h1>
              <p className="text-muted-foreground text-sm mt-1">
                Review and approve/reject extra charge requests from doctors
              </p>
            </div>

            {/* Filters and Search */}
            <div className="bg-card rounded-lg shadow-md border border-border p-4 mb-6">
              <div className="flex flex-col lg:flex-row gap-4">
                {/* Search */}
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <input
                    type="text"
                    placeholder="Search by patient, doctor, or reason..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-foreground placeholder-muted-foreground text-sm"
                  />
                </div>

                {/* Status Filter */}
                <div className="flex gap-2">
                  {["pending", "approved", "rejected"].map((status) => (
                    <button
                      key={status}
                      onClick={() => setStatusFilter(status)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                        statusFilter === status
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted hover:bg-muted/80 text-muted-foreground"
                      }`}
                    >
                      {status.charAt(0).toUpperCase() + status.slice(1)}
                    </button>
                  ))}
                </div>

                {/* Refresh */}
                <button
                  onClick={fetchBillingRequests}
                  disabled={loading.requests}
                  className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground px-4 py-2 rounded-lg transition-colors font-medium text-sm disabled:opacity-50 cursor-pointer"
                >
                  <Loader2 className={`w-4 h-4 ${loading.requests ? "animate-spin" : ""}`} />
                  {loading.requests ? "Loading..." : "Refresh"}
                </button>
              </div>
            </div>

            {/* Requests Table */}
            <div className="bg-card rounded-lg shadow-md border border-border overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted border-b border-border">
                    <tr>
                      <th className="text-left px-4 sm:px-6 py-3 font-semibold text-muted-foreground">Patient</th>
                      <th className="text-left px-4 sm:px-6 py-3 font-semibold text-muted-foreground hidden sm:table-cell">
                        Doctor
                      </th>
                      <th className="text-left px-4 sm:px-6 py-3 font-semibold text-muted-foreground hidden md:table-cell">
                        Amount
                      </th>
                      <th className="text-left px-4 sm:px-6 py-3 font-semibold text-muted-foreground hidden lg:table-cell">
                        Reason
                      </th>
                      <th className="text-left px-4 sm:px-6 py-3 font-semibold text-muted-foreground">Status</th>
                      <th className="text-left px-4 sm:px-6 py-3 font-semibold text-muted-foreground">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loading.requests ? (
                      <tr>
                        <td colSpan={6} className="px-4 sm:px-6 py-8 text-center">
                          <div className="flex flex-col items-center justify-center gap-3">
                            <div className="flex justify-center items-center gap-2">
                              <div className="w-3 h-3 bg-primary rounded-full animate-bounce"></div>
                              <div
                                className="w-3 h-3 bg-primary rounded-full animate-bounce"
                                style={{ animationDelay: "0.1s" }}
                              ></div>
                              <div
                                className="w-3 h-3 bg-primary rounded-full animate-bounce"
                                style={{ animationDelay: "0.2s" }}
                              ></div>
                            </div>
                            <span className="text-muted-foreground text-sm">Loading requests...</span>
                          </div>
                        </td>
                      </tr>
                    ) : currentRequests.length > 0 ? (
                      currentRequests.map((request) => (
                        <tr key={request._id} className="border-b border-border hover:bg-muted/50 transition-colors">
                          <td className="px-4 sm:px-6 py-3 font-medium text-foreground">
                            <div>
                              <div className="sm:hidden text-xs text-muted-foreground mb-1">Patient</div>
                              {request.patientName}
                            </div>
                          </td>
                          <td className="px-4 sm:px-6 py-3 text-muted-foreground hidden sm:table-cell">
                            <div>
                              <div className="md:hidden text-xs text-muted-foreground mb-1">Doctor</div>
                              {request.doctorName}
                            </div>
                          </td>
                          <td className="px-4 sm:px-6 py-3 font-semibold text-primary hidden md:table-cell">
                            <div>
                              <div className="lg:hidden text-xs text-muted-foreground mb-1">Amount</div>$
                              {request.extraChargesRequested?.amount || 0}
                            </div>
                          </td>
                          <td className="px-4 sm:px-6 py-3 text-muted-foreground hidden lg:table-cell max-w-xs truncate">
                            {request.extraChargesRequested?.reason || "No reason provided"}
                          </td>
                          <td className="px-4 sm:px-6 py-3">
                            <div>
                              <div className="sm:hidden text-xs text-muted-foreground mb-1">Status</div>
                              {request.extraChargesRequested?.status === "pending" ? (
                                <span className="inline-flex items-center gap-1 px-2 py-1 bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300 rounded-full text-xs font-medium">
                                  <Clock className="w-3 h-3" />
                                  Pending
                                </span>
                              ) : request.extraChargesRequested?.status === "approved" ? (
                                <span className="inline-flex items-center gap-1 px-2 py-1 bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300 rounded-full text-xs font-medium">
                                  <CheckCircle className="w-3 h-3" />
                                  Approved
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2 py-1 bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300 rounded-full text-xs font-medium">
                                  <XCircle className="w-3 h-3" />
                                  Rejected
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-4 sm:px-6 py-3">
                            {request.extraChargesRequested?.status === "pending" ? (
                              <div className="flex gap-2">
                                <button
                                  onClick={() => handleApprove(request._id)}
                                  disabled={processingId === request._id}
                                  className="text-green-600 hover:text-green-700 disabled:text-green-400 transition-colors cursor-pointer disabled:cursor-not-allowed"
                                  title="Approve"
                                >
                                  {processingId === request._id ? (
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                  ) : (
                                    <Check className="w-4 h-4" />
                                  )}
                                </button>
                                <button
                                  onClick={() => handleReject(request._id)}
                                  disabled={processingId === request._id}
                                  className="text-red-600 hover:text-red-700 disabled:text-red-400 transition-colors cursor-pointer disabled:cursor-not-allowed"
                                  title="Reject"
                                >
                                  {processingId === request._id ? (
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                  ) : (
                                    <X className="w-4 h-4" />
                                  )}
                                </button>
                              </div>
                            ) : (
                              <span className="text-xs text-muted-foreground">
                                {request.extraChargesRequested?.status === "approved" ? "Processed" : "Rejected"}
                              </span>
                            )}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={6} className="px-4 sm:px-6 py-8 text-center text-muted-foreground">
                          {searchTerm ? "No requests found matching your search" : "No billing requests"}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Pagination */}
              {filteredRequests.length > 0 && (
                <div className="px-4 sm:px-6 py-4 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="text-sm text-muted-foreground">
                    Showing <span className="font-medium">{filteredRequests.length === 0 ? 0 : startIndex + 1}</span> to{" "}
                    <span className="font-medium">{Math.min(endIndex, filteredRequests.length)}</span> of{" "}
                    <span className="font-medium">{filteredRequests.length}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                      className="p-2 rounded border border-border bg-background hover:bg-muted disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>

                    <div className="flex items-center gap-1">
                      {Array.from({ length: totalPages }, (_, i) => i + 1)
                        .filter((page) => page === 1 || page === totalPages || Math.abs(page - currentPage) <= 1)
                        .map((page, index, array) => {
                          const showEllipsis = index < array.length - 1 && array[index + 1] - page > 1
                          return (
                            <div key={page} className="flex items-center">
                              <button
                                onClick={() => setCurrentPage(page)}
                                className={`min-w-[2rem] h-8 px-2 rounded text-sm font-medium transition-colors ${
                                  currentPage === page
                                    ? "bg-primary text-primary-foreground"
                                    : "bg-background text-foreground hover:bg-muted border border-border"
                                }`}
                              >
                                {page}
                              </button>
                              {showEllipsis && <span className="px-1 text-muted-foreground">...</span>}
                            </div>
                          )
                        })}
                    </div>

                    <button
                      onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages || totalPages === 0}
                      className="p-2 rounded border border-border bg-background hover:bg-muted disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </ProtectedRoute>
  )
}
