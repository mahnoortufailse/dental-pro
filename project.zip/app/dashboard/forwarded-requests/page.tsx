//@ts-nocheck
"use client"

import type React from "react"

import { ProtectedRoute } from "@/components/protected-route"
import { Sidebar } from "@/components/sidebar"
import { useAuth } from "@/components/auth-context"
import { useState, useEffect } from "react"
import { toast } from "react-hot-toast"
import {
  Upload,
  CheckCircle,
  AlertCircle,
  Loader2,
  Camera,
  X,
  User,
  Phone,
  Mail,
  Calendar,
  MapPin,
  FileText,
  Stethoscope,
  XCircle,
} from "lucide-react"
import { useRouter } from "next/navigation"
import { validateAppointmentScheduling } from "@/lib/appointment-validation"

interface PatientReferral {
  _id: string
  id: string
  doctorId: string
  doctorName: string
  patientName: string
  patientPhone: string
  patientEmail: string
  patientDob: string
  patientIdNumber: string
  patientAddress: string
  patientAllergies: string[]
  patientMedicalConditions: string[]
  referralReason: string
  status: "pending" | "in-progress" | "completed" | "rejected"
  pictureUrl?: string
  pictureSavedBy?: string
  appointmentId?: string
  notes: string
  createdAt: string
  updatedAt: string
}

export default function ForwardedRequestsPage() {
  const { user, token } = useAuth()
  const router = useRouter()
  const [referrals, setReferrals] = useState<PatientReferral[]>([])
  const [loading, setLoading] = useState({
    fetch: false,
    upload: false,
    createAppointment: false,
  })
  const [selectedReferral, setSelectedReferral] = useState<PatientReferral | null>(null)
  const [showDetailModal, setShowDetailModal] = useState(false)
  const [showRejectModal, setShowRejectModal] = useState(false)
  const [rejectReason, setRejectReason] = useState("")
  const [pictureFile, setPictureFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string>("")
  const [formData, setFormData] = useState({
    appointmentDate: "",
    appointmentTime: "",
    appointmentType: "Consultation",
    roomNumber: "",
    duration: 30,
    notes: "",
  })
  const [formErrors, setFormErrors] = useState<Record<string, string>>({})
  const [activeTab, setActiveTab] = useState<"patient" | "appointment">("patient")

  useEffect(() => {
    if (token && (user?.role === "receptionist" || user?.role === "admin")) {
      fetchReferrals()
    }
  }, [token, user])

  const fetchReferrals = async () => {
    setLoading((prev) => ({ ...prev, fetch: true }))
    try {
      const res = await fetch("/api/patient-referrals", {
        headers: { Authorization: `Bearer ${token}` },
      })
      if (res.ok) {
        const data = await res.json()
        setReferrals(data.referrals || [])
      } else {
        toast.error("Failed to fetch forwarded requests")
      }
    } catch (error) {
      console.error("Failed to fetch referrals:", error)
      toast.error("Error fetching requests")
    } finally {
      setLoading((prev) => ({ ...prev, fetch: false }))
    }
  }

  const handlePictureSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error("Image size must be less than 5MB")
        return
      }
      setPictureFile(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const uploadPicture = async () => {
    if (!pictureFile || !selectedReferral) {
      toast.error("No picture selected")
      return
    }

    setLoading((prev) => ({ ...prev, upload: true }))
    try {
      const formDataObj = new FormData()
      formDataObj.append("file", pictureFile)

      const uploadRes = await fetch("/api/cloudinary/upload", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formDataObj,
      })

      if (!uploadRes.ok) {
        const errorData = await uploadRes.json()
        toast.error(errorData.error || "Failed to upload picture")
        return
      }

      const uploadData = await uploadRes.json()
      const pictureUrl = uploadData.secure_url

      // Update referral with picture
      const updateRes = await fetch(`/api/patient-referrals/${selectedReferral._id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          pictureUrl,
          pictureSavedBy: user?.name || "Staff",
          status: "in-progress",
        }),
      })

      if (updateRes.ok) {
        toast.success("Picture uploaded successfully")
        setPictureFile(null)
        setPreviewUrl("")
        // Refresh the referral data
        const updated = await updateRes.json()
        setSelectedReferral(updated.referral)
        setReferrals(referrals.map((r) => (r._id === selectedReferral._id ? updated.referral : r)))
      } else {
        const errorData = await updateRes.json()
        toast.error(errorData.error || "Failed to update referral")
      }
    } catch (error) {
      console.error("Failed to upload picture:", error)
      toast.error("Error uploading picture")
    } finally {
      setLoading((prev) => ({ ...prev, upload: false }))
    }
  }

  const validateAppointmentForm = (): boolean => {
    const errors: Record<string, string> = {}

    if (!formData.appointmentDate) {
      errors.appointmentDate = "Date is required"
    } else {
      const selectedDate = new Date(formData.appointmentDate)
      const today = new Date()
      today.setHours(0, 0, 0, 0)
      if (selectedDate < today) {
        errors.appointmentDate = "Cannot schedule appointments in the past"
      }
    }

    if (!formData.appointmentTime) {
      errors.appointmentTime = "Time is required"
    }

    if (!formData.roomNumber.trim()) {
      errors.roomNumber = "Room Number is required"
    }

    if (formData.duration <= 0) {
      errors.duration = "Duration must be greater than 0"
    }

    setFormErrors(errors)
    return Object.keys(errors).length === 0
  }

  const createAppointmentAndCompleteReferral = async () => {
    if (!selectedReferral || !validateAppointmentForm()) {
      toast.error("Please fix the errors in the form")
      return
    }

    // Validate and format the date of birth
    const patientDob = selectedReferral.patientDob
    if (!patientDob) {
      toast.error("Patient date of birth is required")
      return
    }

    let formattedDob
    try {
      const dobDate = new Date(patientDob)
      if (isNaN(dobDate.getTime())) {
        toast.error("Invalid date of birth format")
        return
      }
      formattedDob = dobDate.toISOString().split("T")[0]
    } catch (error) {
      toast.error("Invalid date of birth")
      return
    }

    console.log("[v0] Validating appointment time conflict for doctor:", selectedReferral.doctorId)
    const validation = await validateAppointmentScheduling(
      selectedReferral.doctorId,
      formData.appointmentDate,
      formData.appointmentTime,
      formData.duration || 30,
      token,
      undefined,
    )

    if (!validation.isValid) {
      toast.error(validation.error || "Time conflict detected. Please choose another time.")
      return
    }

    setLoading((prev) => ({ ...prev, createAppointment: true }))
    try {
      // Prepare patient data with ALL required fields from backend
      const patientData = {
        name: selectedReferral.patientName,
        phone: selectedReferral.patientPhone,
        email: selectedReferral.patientEmail || "",
        dob: formattedDob,
        idNumber: selectedReferral.patientIdNumber || "N/A",
        address: selectedReferral.patientAddress || "",
        insuranceProvider: "",
        insuranceNumber: "",
        allergies: selectedReferral.patientAllergies || [],
        medicalConditions: selectedReferral.patientMedicalConditions || [],
        assignedDoctorId: selectedReferral.doctorId,
        photoUrl: selectedReferral.pictureUrl || null,
      }

      console.log("Sending patient data to API:", patientData)

      const patientRes = await fetch("/api/patients", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(patientData),
      })

      console.log("Patient API response status:", patientRes.status)

      let patientId
      if (patientRes.ok) {
        const patientResponse = await patientRes.json()
        patientId = patientResponse.patient._id
        console.log("Patient created successfully, ID:", patientId)
      } else if (patientRes.status === 409) {
        // Patient already exists
        const patientResponse = await patientRes.json()
        patientId = patientResponse.patient._id
        console.log("Patient already exists, ID:", patientId)
      } else {
        const errorData = await patientRes.json()
        console.error("Patient creation failed:", errorData)

        if (errorData.error && errorData.error.includes("Email already exists in staff records")) {
          toast.error(
            <div className="text-center">
              <div className="font-semibold">Email Conflict Detected</div>
              <div className="text-sm mt-1">{errorData.error}</div>
            </div>,
            {
              duration: 8000,
              icon: "❌",
            },
          )
          // Auto-reject the forward request if email conflict
          await rejectForwardRequest("Email conflict: " + errorData.error)
          return
        }

        toast.error(errorData.error || `Failed to create patient: ${patientRes.status}`)
        return
      }

      // Create the appointment
      const appointmentRes = await fetch("/api/appointments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          patientId,
          patientName: selectedReferral.patientName,
          doctorId: selectedReferral.doctorId,
          doctorName: selectedReferral.doctorName,
          date: formData.appointmentDate,
          time: formData.appointmentTime,
          type: formData.appointmentType,
          roomNumber: formData.roomNumber,
          duration: formData.duration,
        }),
      })

      if (appointmentRes.ok) {
        const appointmentData = await appointmentRes.json()
        const appointmentId = appointmentData.appointment._id

        // Update referral as completed
        const updateRes = await fetch(`/api/patient-referrals/${selectedReferral._id}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            status: "completed",
            appointmentId,
            notes: formData.notes,
          }),
        })

        if (updateRes.ok) {
          toast.success("Patient registered and appointment booked successfully")
          setShowDetailModal(false)
          setSelectedReferral(null)
          setPictureFile(null)
          setPreviewUrl("")
          setFormData({
            appointmentDate: "",
            appointmentTime: "",
            appointmentType: "Consultation",
            roomNumber: "",
            duration: 30,
            notes: "",
          })
          setFormErrors({})
          fetchReferrals()
        } else {
          const errorData = await updateRes.json()
          toast.error(errorData.error || "Failed to update referral status")
        }
      } else {
        const errorData = await appointmentRes.json()
        toast.error(errorData.error || "Failed to create appointment")
      }
    } catch (error) {
      console.error("Failed to create appointment:", error)
      toast.error("Error creating appointment")
    } finally {
      setLoading((prev) => ({ ...prev, createAppointment: false }))
    }
  }

  const rejectForwardRequest = async (reason?: string) => {
    if (!selectedReferral) return

    try {
      const updateRes = await fetch(`/api/patient-referrals/${selectedReferral._id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          status: "rejected",
          rejectionReason: reason || rejectReason,
        }),
      })

      if (updateRes.ok) {
        toast.success("Forward request rejected successfully")
        setShowDetailModal(false)
        setShowRejectModal(false)
        setSelectedReferral(null)
        setRejectReason("")
        fetchReferrals()
      } else {
        const errorData = await updateRes.json()
        toast.error(errorData.error || "Failed to reject request")
      }
    } catch (error) {
      console.error("Failed to reject request:", error)
      toast.error("Error rejecting request")
    }
  }

  const handleOpenReferral = (referral: PatientReferral) => {
    setSelectedReferral(referral)
    setShowDetailModal(true)
    setPictureFile(null)
    setPreviewUrl(referral.pictureUrl || "")
    setFormData({
      appointmentDate: "",
      appointmentTime: "",
      appointmentType: "Consultation",
      roomNumber: "",
      duration: 30,
      notes: referral.notes || "",
    })
    setFormErrors({})
    setActiveTab("patient")
    setShowRejectModal(false)
    setRejectReason("")
  }

  if (user?.role !== "receptionist" && user?.role !== "admin") {
    return (
      <ProtectedRoute>
        <div className="flex h-screen bg-background">
          <Sidebar />
          <main className="flex-1 overflow-auto md:pt-0 pt-16">
            <div className="p-4 sm:p-6 lg:p-8">
              <div className="text-center py-12">
                <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
                <h1 className="text-2xl font-bold text-foreground mb-2">Access Denied</h1>
                <p className="text-muted-foreground">Only receptionist and admin can view forwarded requests.</p>
              </div>
            </div>
          </main>
        </div>
      </ProtectedRoute>
    )
  }

  return (
    <ProtectedRoute>
      <div className="flex h-screen bg-background">
        <Sidebar />
        <main className="flex-1 overflow-auto md:pt-0 pt-16">
          <div className="p-4 sm:p-6 lg:p-8">
            <div className="mb-8">
              <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Forwarded Patient Requests</h1>
              <p className="text-muted-foreground text-sm mt-1">
                Review and process patient referral requests from doctors
              </p>
            </div>

            {loading.fetch ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : referrals.length === 0 ? (
              <div className="text-center py-12 bg-card rounded-lg border border-border">
                <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No pending forwarded requests at the moment.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {referrals.map((referral) => (
                  <div
                    key={referral._id}
                    className="bg-card rounded-lg shadow-md border border-border p-6 hover:shadow-lg transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-semibold text-foreground">{referral.patientName}</h3>
                        <p className="text-sm text-muted-foreground">Referred by: {referral.doctorName}</p>
                      </div>
                      <span
                        className={`text-xs px-2 py-1 rounded font-medium ${
                          referral.status === "pending"
                            ? "bg-amber-100 text-amber-800"
                            : referral.status === "in-progress"
                              ? "bg-blue-100 text-blue-800"
                              : referral.status === "completed"
                                ? "bg-green-100 text-green-800"
                                : "bg-red-100 text-red-800"
                        }`}
                      >
                        {referral.status}
                      </span>
                    </div>

                    <div className="space-y-2 mb-4 text-sm">
                      <p className="text-muted-foreground">
                        <strong>Phone:</strong> {referral.patientPhone}
                      </p>
                      <p className="text-muted-foreground">
                        <strong>DOB:</strong> {referral.patientDob}
                      </p>
                      <p className="text-muted-foreground">
                        <strong>Reason:</strong> {referral.referralReason}
                      </p>
                    </div>

                    {/* Only show button for pending and in-progress statuses */}
                    {(referral.status === "pending" || referral.status === "in-progress") && (
                      <button
                        onClick={() => handleOpenReferral(referral)}
                        disabled={loading.createAppointment}
                        className="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 disabled:bg-primary/50 text-primary-foreground px-4 py-2 rounded-lg transition-colors font-medium cursor-pointer disabled:cursor-not-allowed"
                      >
                        <CheckCircle className="w-4 h-4" />
                        Review & Process
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}

            {showDetailModal && selectedReferral && (
              <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
                <div className="bg-card rounded-xl shadow-2xl border border-border max-w-4xl w-full max-h-[95vh] overflow-hidden flex flex-col">
                  {/* Header */}
                  <div className="flex items-center justify-between p-6 border-b border-border bg-gradient-to-r from-primary/5 to-primary/10">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <User className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <h2 className="text-2xl font-bold text-foreground">{selectedReferral.patientName}</h2>
                        <p className="text-sm text-muted-foreground flex items-center gap-1">
                          <Stethoscope className="w-4 h-4" />
                          Referred by Dr. {selectedReferral.doctorName}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => setShowDetailModal(false)}
                      className="p-2 hover:bg-muted rounded-lg transition-colors text-muted-foreground hover:text-foreground"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Tabs */}
                  <div className="border-b border-border bg-muted/30">
                    <div className="flex px-6">
                      <button
                        onClick={() => setActiveTab("patient")}
                        className={`px-4 py-3 font-medium text-sm border-b-2 transition-colors ${
                          activeTab === "patient"
                            ? "border-primary text-primary"
                            : "border-transparent text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        <User className="w-4 h-4 inline mr-2" />
                        Patient Information
                      </button>
                      <button
                        onClick={() => setActiveTab("appointment")}
                        className={`px-4 py-3 font-medium text-sm border-b-2 transition-colors ${
                          activeTab === "appointment"
                            ? "border-primary text-primary"
                            : "border-transparent text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        <Calendar className="w-4 h-4 inline mr-2" />
                        Book Appointment
                      </button>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 overflow-y-auto p-6">
                    {activeTab === "patient" && (
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        {/* Patient Details */}
                        <div className="space-y-6">
                          <div className="bg-muted/30 rounded-lg p-4">
                            <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                              <User className="w-5 h-5 text-primary" />
                              Personal Information
                            </h3>
                            <div className="grid grid-cols-1 gap-4">
                              <div className="flex items-center gap-3">
                                <Phone className="w-4 h-4 text-muted-foreground" />
                                <div>
                                  <p className="text-sm text-muted-foreground">Phone</p>
                                  <p className="text-foreground font-medium">{selectedReferral.patientPhone}</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-3">
                                <Mail className="w-4 h-4 text-muted-foreground" />
                                <div>
                                  <p className="text-sm text-muted-foreground">Email</p>
                                  <p className="text-foreground font-medium">
                                    {selectedReferral.patientEmail || "N/A"}
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center gap-3">
                                <Calendar className="w-4 h-4 text-muted-foreground" />
                                <div>
                                  <p className="text-sm text-muted-foreground">Date of Birth</p>
                                  <p className="text-foreground font-medium">{selectedReferral.patientDob}</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-3">
                                <MapPin className="w-4 h-4 text-muted-foreground" />
                                <div>
                                  <p className="text-sm text-muted-foreground">Address</p>
                                  <p className="text-foreground font-medium">
                                    {selectedReferral.patientAddress || "N/A"}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Medical Information */}
                          <div className="bg-muted/30 rounded-lg p-4">
                            <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                              <FileText className="w-5 h-5 text-primary" />
                              Medical Information
                            </h3>
                            <div className="space-y-4">
                              {selectedReferral.patientAllergies.length > 0 && (
                                <div>
                                  <p className="text-sm text-muted-foreground font-medium mb-1">Allergies</p>
                                  <div className="flex flex-wrap gap-1">
                                    {selectedReferral.patientAllergies.map((allergy, index) => (
                                      <span
                                        key={index}
                                        className="px-2 py-1 bg-amber-100 text-amber-800 text-xs rounded-full font-medium"
                                      >
                                        {allergy}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              )}
                              {selectedReferral.patientMedicalConditions.length > 0 && (
                                <div>
                                  <p className="text-sm text-muted-foreground font-medium mb-1">Medical Conditions</p>
                                  <div className="flex flex-wrap gap-1">
                                    {selectedReferral.patientMedicalConditions.map((condition, index) => (
                                      <span
                                        key={index}
                                        className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full font-medium"
                                      >
                                        {condition}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              )}
                              <div>
                                <p className="text-sm text-muted-foreground font-medium mb-1">Referral Reason</p>
                                <p className="text-foreground bg-primary/10 rounded-lg p-3 text-sm">
                                  {selectedReferral.referralReason}
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Picture Upload */}
                        <div className="space-y-6">
                          <div className="bg-muted/30 rounded-lg p-4">
                            <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                              <Camera className="w-5 h-5 text-primary" />
                              Patient Photo
                            </h3>
                            <div className="space-y-4">
                              <div className="border-2 border-dashed border-border rounded-xl p-6 transition-colors hover:border-primary/50">
                                {previewUrl ? (
                                  <div className="text-center">
                                    <img
                                      src={previewUrl || "/placeholder.svg"}
                                      alt="Patient"
                                      className="w-48 h-48 object-cover rounded-lg mx-auto mb-4 shadow-md"
                                    />
                                    {!selectedReferral.pictureUrl && (
                                      <button
                                        onClick={() => {
                                          setPictureFile(null)
                                          setPreviewUrl("")
                                        }}
                                        className="text-sm text-destructive hover:text-destructive/80 font-medium"
                                      >
                                        Remove Photo
                                      </button>
                                    )}
                                  </div>
                                ) : (
                                  <div className="flex flex-col items-center justify-center py-8 text-center">
                                    <Camera className="w-12 h-12 text-muted-foreground mb-4" />
                                    <label className="cursor-pointer">
                                      <span className="text-primary hover:underline font-medium text-lg">
                                        Click to upload photo
                                      </span>
                                      <input
                                        type="file"
                                        accept="image/*"
                                        onChange={handlePictureSelect}
                                        className="hidden"
                                        disabled={loading.upload || selectedReferral.pictureUrl ? true : false}
                                      />
                                    </label>
                                    <p className="text-sm text-muted-foreground mt-2">JPG, PNG, or WebP • Max 5MB</p>
                                  </div>
                                )}
                              </div>

                              {pictureFile && !selectedReferral.pictureUrl && (
                                <button
                                  onClick={uploadPicture}
                                  disabled={loading.upload}
                                  className="w-full flex items-center justify-center gap-2 bg-accent hover:bg-accent/90 disabled:bg-accent/50 text-accent-foreground px-4 py-3 rounded-lg transition-colors font-medium cursor-pointer disabled:cursor-not-allowed shadow-sm"
                                >
                                  {loading.upload ? (
                                    <>
                                      <Loader2 className="w-4 h-4 animate-spin" />
                                      Uploading...
                                    </>
                                  ) : (
                                    <>
                                      <Upload className="w-4 h-4" />
                                      Upload Patient Photo
                                    </>
                                  )}
                                </button>
                              )}

                              {selectedReferral.pictureUrl && (
                                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                                  <p className="text-sm text-green-800 font-medium flex items-center gap-2">
                                    <CheckCircle className="w-4 h-4" />
                                    Photo uploaded by {selectedReferral.pictureSavedBy}
                                  </p>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Quick Actions */}
                          <div className="bg-muted/30 rounded-lg p-4">
                            <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
                            <button
                              onClick={() => setActiveTab("appointment")}
                              className="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground px-4 py-3 rounded-lg transition-colors font-medium shadow-sm mb-3"
                            >
                              <Calendar className="w-4 h-4" />
                              Proceed to Book Appointment
                            </button>
                            <button
                              onClick={() => setShowRejectModal(true)}
                              className="w-full flex items-center justify-center gap-2 bg-destructive hover:bg-destructive/90 text-white px-4 py-3 rounded-lg transition-colors font-medium shadow-sm"
                            >
                              <XCircle className="w-4 h-4" />
                              Reject Request
                            </button>
                          </div>
                        </div>
                      </div>
                    )}

                    {activeTab === "appointment" && (
                      <div className="space-y-6">
                        <div className="bg-muted/30 rounded-lg p-6">
                          <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center gap-2">
                            <Calendar className="w-5 h-5 text-primary" />
                            Schedule Appointment
                          </h3>

                          <form className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <label className="block text-sm font-medium text-foreground">Appointment Date *</label>
                              <input
                                type="date"
                                value={formData.appointmentDate}
                                onChange={(e) => {
                                  setFormData({ ...formData, appointmentDate: e.target.value })
                                  setFormErrors({ ...formErrors, appointmentDate: "" })
                                }}
                                disabled={loading.createAppointment}
                                className={`w-full px-3 py-2 bg-background border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-foreground text-sm transition-colors ${
                                  formErrors.appointmentDate ? "border-destructive" : "border-border"
                                }`}
                              />
                              {formErrors.appointmentDate && (
                                <p className="text-xs text-destructive mt-1">{formErrors.appointmentDate}</p>
                              )}
                            </div>

                            <div className="space-y-2">
                              <label className="block text-sm font-medium text-foreground">Appointment Time *</label>
                              <input
                                type="time"
                                value={formData.appointmentTime}
                                onChange={(e) => {
                                  setFormData({ ...formData, appointmentTime: e.target.value })
                                  setFormErrors({ ...formErrors, appointmentTime: "" })
                                }}
                                disabled={loading.createAppointment}
                                className={`w-full px-3 py-2 bg-background border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-foreground text-sm transition-colors ${
                                  formErrors.appointmentTime ? "border-destructive" : "border-border"
                                }`}
                              />
                              {formErrors.appointmentTime && (
                                <p className="text-xs text-destructive mt-1">{formErrors.appointmentTime}</p>
                              )}
                            </div>

                            <div className="space-y-2">
                              <label className="block text-sm font-medium text-foreground">Appointment Type</label>
                              <select
                                value={formData.appointmentType}
                                onChange={(e) => setFormData({ ...formData, appointmentType: e.target.value })}
                                disabled={loading.createAppointment}
                                className="w-full px-3 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-foreground text-sm transition-colors"
                              >
                                <option value="Consultation">Consultation</option>
                                <option value="Cleaning">Cleaning</option>
                                <option value="Filling">Filling</option>
                                <option value="Root Canal">Root Canal</option>
                              </select>
                            </div>

                            <div className="space-y-2">
                              <label className="block text-sm font-medium text-foreground">Duration (minutes)</label>
                              <input
                                type="number"
                                min="1"
                                value={formData.duration}
                                onChange={(e) =>
                                  setFormData({
                                    ...formData,
                                    duration: Number.parseInt(e.target.value) || 30,
                                  })
                                }
                                disabled={loading.createAppointment}
                                className="w-full px-3 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-foreground text-sm transition-colors"
                              />
                            </div>

                            <div className="md:col-span-2 space-y-2">
                              <label className="block text-sm font-medium text-foreground">Room Number *</label>
                              <input
                                type="text"
                                placeholder="e.g., Room 1, Suite A, etc."
                                value={formData.roomNumber}
                                onChange={(e) => {
                                  setFormData({ ...formData, roomNumber: e.target.value })
                                  setFormErrors({ ...formErrors, roomNumber: "" })
                                }}
                                disabled={loading.createAppointment}
                                className={`w-full px-3 py-2 bg-background border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-foreground placeholder-muted-foreground text-sm transition-colors ${
                                  formErrors.roomNumber ? "border-destructive" : "border-border"
                                }`}
                              />
                              {formErrors.roomNumber && (
                                <p className="text-xs text-destructive mt-1">{formErrors.roomNumber}</p>
                              )}
                            </div>

                            <div className="md:col-span-2 space-y-2">
                              <label className="block text-sm font-medium text-foreground">Additional Notes</label>
                              <textarea
                                placeholder="Any additional notes or special instructions..."
                                value={formData.notes}
                                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                                disabled={loading.createAppointment}
                                className="w-full px-3 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-foreground placeholder-muted-foreground text-sm transition-colors resize-none"
                                rows={3}
                              />
                            </div>
                          </form>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Footer - Only show on appointment tab */}
                  {activeTab === "appointment" && (
                    <div className="flex gap-3 p-6 border-t border-border bg-muted/30">
                      <button
                        onClick={() => setShowDetailModal(false)}
                        disabled={loading.createAppointment}
                        className="flex-1 bg-muted hover:bg-muted/80 disabled:bg-muted/50 text-muted-foreground px-4 py-3 rounded-lg transition-colors font-medium cursor-pointer disabled:cursor-not-allowed shadow-sm"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={createAppointmentAndCompleteReferral}
                        disabled={loading.createAppointment}
                        className="flex-1 flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 disabled:bg-primary/50 text-primary-foreground px-4 py-3 rounded-lg transition-colors font-medium cursor-pointer disabled:cursor-not-allowed shadow-sm"
                      >
                        {loading.createAppointment ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          <>
                            <CheckCircle className="w-4 h-4" />
                            Book Appointment & Complete
                          </>
                        )}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {showRejectModal && selectedReferral && (
              <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
                <div className="bg-card rounded-xl shadow-2xl border border-border max-w-md w-full">
                  <div className="p-6 border-b border-border">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-destructive/10 rounded-lg">
                        <AlertCircle className="w-6 h-6 text-destructive" />
                      </div>
                      <h2 className="text-xl font-bold text-foreground">Reject Request</h2>
                    </div>
                  </div>

                  <div className="p-6 space-y-4">
                    <p className="text-muted-foreground">
                      Are you sure you want to reject this forwarded request from Dr. {selectedReferral.doctorName}?
                    </p>

                    <div className="space-y-2">
                      <label className="block text-sm font-medium text-foreground">Rejection Reason (Optional)</label>
                      <textarea
                        placeholder="Enter the reason for rejecting this request..."
                        value={rejectReason}
                        onChange={(e) => setRejectReason(e.target.value)}
                        className="w-full px-3 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-destructive text-foreground placeholder-muted-foreground text-sm transition-colors resize-none"
                        rows={3}
                      />
                    </div>
                  </div>

                  <div className="flex gap-3 p-6 border-t border-border bg-muted/30">
                    <button
                      onClick={() => setShowRejectModal(false)}
                      className="flex-1 bg-muted hover:bg-muted/80 text-muted-foreground px-4 py-2 rounded-lg transition-colors font-medium shadow-sm"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => rejectForwardRequest()}
                      className="flex-1 flex items-center justify-center gap-2 bg-destructive hover:bg-destructive/90 text-white px-4 py-2 rounded-lg transition-colors font-medium shadow-sm"
                    >
                      <XCircle className="w-4 h-4" />
                      Reject
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </ProtectedRoute>
  )
}
