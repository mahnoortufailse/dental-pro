//@ts-nocheck
"use client"

import { ProtectedRoute } from "@/components/protected-route"
import { Sidebar } from "@/components/sidebar"
import { useAuth } from "@/components/auth-context"
import { useEffect, useState } from "react"
import { Users, Calendar, TrendingUp, AlertCircle, UserPlus, ArrowRightLeft } from "lucide-react"
import Link from "next/link"

export default function DashboardPage() {
  const { user, token } = useAuth()
  const [stats, setStats] = useState({
    appointments: 0,
    patients: 0,
    lowStock: 0,
    revenue: 0,
    pendingRequests: 0,
    patientReferrals: 0,
    appointmentReferrals: 0,
  })
  const [appointments, setAppointments] = useState([])
  const [doctorRequests, setDoctorRequests] = useState([])

  const isToday = (dateString: string) => {
    const appointmentDate = new Date(dateString)
    const today = new Date()
    return (
      appointmentDate.getFullYear() === today.getFullYear() &&
      appointmentDate.getMonth() === today.getMonth() &&
      appointmentDate.getDate() === today.getDate()
    )
  }

  useEffect(() => {
    if (token) {
      fetchDashboardData()
    }
  }, [token])

  const fetchDashboardData = async () => {
    try {
      const [appointmentsRes, patientsRes, inventoryRes, billingRes, referralsRes, patientReferralsRes] =
        await Promise.allSettled([
          fetch("/api/appointments", { headers: { Authorization: `Bearer ${token}` } }),
          fetch("/api/patients", { headers: { Authorization: `Bearer ${token}` } }),
          fetch("/api/inventory", { headers: { Authorization: `Bearer ${token}` } }).catch(() => null),
          fetch("/api/billing", { headers: { Authorization: `Bearer ${token}` } }).catch(() => null),
          user?.role === "doctor"
            ? fetch("/api/appointment-referrals?type=all", { headers: { Authorization: `Bearer ${token}` } })
            : Promise.resolve(null),
          user?.role === "doctor"
            ? fetch("/api/patient-referrals", { headers: { Authorization: `Bearer ${token}` } })
            : Promise.resolve(null),
        ])

      let appointmentCount = 0
      let patientCount = 0
      let lowStockCount = 0
      let totalRevenue = 0
      let pendingRequestsCount = 0
      let patientReferralsCount = 0
      let appointmentReferralsCount = 0

      if (appointmentsRes.status === "fulfilled" && appointmentsRes.value.ok) {
        const data = await appointmentsRes.value.json()
        const todayAppointments = (data.appointments || []).filter((apt: any) => isToday(apt.date))
        setAppointments(todayAppointments)
        appointmentCount = todayAppointments.length
      }

      if (patientsRes.status === "fulfilled" && patientsRes.value.ok) {
        const data = await patientsRes.value.json()
        patientCount = data.patients?.length || 0
      }

      if (inventoryRes?.status === "fulfilled" && inventoryRes.value?.ok) {
        const data = await inventoryRes.value.json()
        lowStockCount = data.inventory?.filter((item: any) => item.quantity < item.minStock).length || 0
      }

      if (billingRes?.status === "fulfilled" && billingRes.value?.ok) {
        const data = await billingRes.value.json()
        totalRevenue = data.billing?.reduce((sum: number, b: any) => sum + b.totalAmount, 0) || 0
      }

      if (user?.role === "doctor" && referralsRes?.status === "fulfilled" && referralsRes.value?.ok) {
        const data = await referralsRes.value.json()
        setDoctorRequests(data.referrals || [])
        appointmentReferralsCount = (data.referrals || []).length
        pendingRequestsCount = (data.referrals || []).filter(
          (r: any) => r.status === "pending" || r.status === "accepted",
        ).length
      }

      if (user?.role === "doctor" && patientReferralsRes?.status === "fulfilled" && patientReferralsRes.value?.ok) {
        const data = await patientReferralsRes.value.json()
        patientReferralsCount = (data.referrals || []).length
      }

      setStats({
        appointments: appointmentCount,
        patients: patientCount,
        lowStock: lowStockCount,
        revenue: totalRevenue,
        pendingRequests: pendingRequestsCount,
        patientReferrals: patientReferralsCount,
        appointmentReferrals: appointmentReferralsCount,
      })
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error)
    }
  }

  return (
    <ProtectedRoute>
      <div className="flex h-screen bg-background">
        <Sidebar />
        <main className="flex-1 overflow-auto lg:ml-0">
          <div className="p-4 sm:p-6 lg:p-8">
            <div className="dashboard-header">
              <div>
                <h1 className="dashboard-title">Welcome back, {user?.name}!</h1>
                <p className="text-muted-foreground mt-1 text-sm sm:text-base">
                  Here's what's happening at your clinic today
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-6 sm:mb-8">
              <div className="stat-card">
                <div className="stat-icon bg-gradient-to-br from-primary/20 to-primary/10">
                  <Calendar className="w-6 h-6 text-primary" />
                </div>
                <p className="stat-label">Today's Appointments</p>
                <p className="stat-value">{stats.appointments}</p>
              </div>

              <div className="stat-card">
                <div className="stat-icon bg-gradient-to-br from-accent/20 to-accent/10">
                  <Users className="w-6 h-6 text-accent" />
                </div>
                <p className="stat-label">Active Patients</p>
                <p className="stat-value">{stats.patients}</p>
              </div>

              {user?.role === "doctor" && (
                <>
                  <Link
                    href="/dashboard/request-status"
                    className="stat-card hover:shadow-lg transition-shadow cursor-pointer"
                  >
                    <div className="stat-icon bg-gradient-to-br from-indigo-100 to-indigo-50">
                      <ArrowRightLeft className="w-6 h-6 text-indigo-600" />
                    </div>
                    <p className="stat-label">Appointment Forwards</p>
                    <p className="stat-value">{stats.appointmentReferrals}</p>
                    <p className="text-xs text-muted-foreground mt-1">Appointments forwarded to/from doctors</p>
                  </Link>

                  <Link
                    href="/dashboard/request-status"
                    className="stat-card hover:shadow-lg transition-shadow cursor-pointer"
                  >
                    <div className="stat-icon bg-gradient-to-br from-emerald-100 to-emerald-50">
                      <UserPlus className="w-6 h-6 text-emerald-600" />
                    </div>
                    <p className="stat-label">New Patient Requests</p>
                    <p className="stat-value">{stats.patientReferrals}</p>
                    <p className="text-xs text-muted-foreground mt-1">Unregistered patients sent to reception for appointment</p>
                  </Link>
                </>
              )}

              {user?.role !== "doctor" && (
                <>
                  <div className="stat-card">
                    <div className="stat-icon bg-gradient-to-br from-destructive/20 to-destructive/10">
                      <AlertCircle className="w-6 h-6 text-destructive" />
                    </div>
                    <p className="stat-label">Low Stock Items</p>
                    <p className="stat-value">{stats.lowStock}</p>
                  </div>

                  <div className="stat-card">
                    <div className="stat-icon bg-gradient-to-br from-secondary/20 to-secondary/10">
                      <TrendingUp className="w-6 h-6 text-secondary" />
                    </div>
                    <p className="stat-label">Total Revenue</p>
                    <p className="stat-value">${stats.revenue.toFixed(0)}</p>
                  </div>
                </>
              )}
            </div>

            {user?.role === "doctor" && doctorRequests.length > 0 && (
              <div className="stat-card mb-6 sm:mb-8">
                <div className="flex items-center justify-between mb-4 sm:mb-6">
                  <h2 className="text-lg sm:text-xl font-bold text-foreground">Recent Appointment Forwards</h2>
                  <Link
                    href="/dashboard/request-status"
                    className="text-sm text-primary hover:text-primary/80 font-medium transition-colors"
                  >
                    View All →
                  </Link>
                </div>
                <div className="table-responsive overflow-x-auto">
                  <table className="w-full text-xs sm:text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-2 sm:py-3 px-2 sm:px-4 font-semibold text-muted-foreground">
                          Patient Name
                        </th>
                        <th className="text-left py-2 sm:py-3 px-2 sm:px-4 font-semibold text-muted-foreground">
                          Direction
                        </th>
                        <th className="text-left py-2 sm:py-3 px-2 sm:px-4 font-semibold text-muted-foreground">
                          Status
                        </th>
                        <th className="text-left py-2 sm:py-3 px-2 sm:px-4 font-semibold text-muted-foreground hidden sm:table-cell">
                          Date
                        </th>
                        <th className="text-left py-2 sm:py-3 px-2 sm:px-4 font-semibold text-muted-foreground">
                          Reason
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {doctorRequests.slice(0, 5).map((req: any) => {
                        const isSent =
                          String(req.fromDoctorId) === String(user.userId) ||
                          String(req.fromDoctorId) === String(user.id)
                        const isReceived =
                          String(req.toDoctorId) === String(user.userId) || String(req.toDoctorId) === String(user.id)

                        return (
                          <tr key={req._id} className="border-b border-border hover:bg-muted/50 transition-colors">
                            <td className="py-2 sm:py-3 px-2 sm:px-4 font-medium">{req.patientName}</td>
                            <td className="py-2 sm:py-3 px-2 sm:px-4">
                              <span
                                className={`text-xs px-2 py-1 rounded-full font-medium ${
                                  isSent
                                    ? "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400"
                                    : "bg-teal-100 text-teal-800 dark:bg-teal-900/30 dark:text-teal-400"
                                }`}
                              >
                                {isSent ? "Forwarded Out" : "Forwarded In"}
                              </span>
                            </td>
                            <td className="py-2 sm:py-3 px-2 sm:px-4">
                              <span
                                className={`text-xs px-2 py-1 rounded-full font-medium ${
                                  req.status === "pending"
                                    ? "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400"
                                    : req.status === "accepted"
                                      ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"
                                      : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"
                                }`}
                              >
                                {req.status}
                              </span>
                            </td>
                            <td className="py-2 sm:py-3 px-2 sm:px-4 hidden sm:table-cell text-muted-foreground">
                              {new Date(req.createdAt).toLocaleDateString()}
                            </td>
                            <td className="py-2 sm:py-3 px-2 sm:px-4 text-muted-foreground truncate max-w-xs">
                              {req.referralReason}
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            <div className="stat-card">
              <h2 className="text-lg sm:text-xl font-bold mb-4 sm:mb-6 text-foreground">Today's Schedule</h2>
              {appointments.length > 0 ? (
                <div className="table-responsive">
                  <table className="w-full text-xs sm:text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-2 sm:py-3 px-2 sm:px-4 font-semibold text-muted-foreground">
                          Time
                        </th>
                        <th className="text-left py-2 sm:py-3 px-2 sm:px-4 font-semibold text-muted-foreground">
                          Patient
                        </th>
                        <th className="text-left py-2 sm:py-3 px-2 sm:px-4 font-semibold text-muted-foreground hidden sm:table-cell">
                          Doctor
                        </th>
                        <th className="text-left py-2 sm:py-3 px-2 sm:px-4 font-semibold text-muted-foreground hidden md:table-cell">
                          Type
                        </th>
                        <th className="text-left py-2 sm:py-3 px-2 sm:px-4 font-semibold text-muted-foreground">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {appointments.slice(0, 5).map((apt) => (
                        <tr key={apt.id} className="table-row">
                          <td className="py-2 sm:py-3 px-2 sm:px-4">{apt.time}</td>
                          <td className="py-2 sm:py-3 px-2 sm:px-4 font-medium">{apt.patientName}</td>
                          <td className="py-2 sm:py-3 px-2 sm:px-4 hidden sm:table-cell">{apt.doctorName}</td>
                          <td className="py-2 sm:py-3 px-2 sm:px-4 hidden md:table-cell">{apt.type}</td>
                          <td className="py-2 sm:py-3 px-2 sm:px-4">
                            <span className="badge-success">{apt.status}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-8 text-sm">No appointments scheduled for today</p>
              )}
            </div>
          </div>
        </main>
      </div>
    </ProtectedRoute>
  )
}
