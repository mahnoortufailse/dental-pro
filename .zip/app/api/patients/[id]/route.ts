// app/api/patients/[id]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { Patient, connectDB } from "@/lib/db";
import { verifyToken } from "@/lib/auth";
import { Types } from "mongoose";

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectDB();
    const token = request.headers.get("authorization")?.split(" ")[1];
    if (!token) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const payload = verifyToken(token);
    if (!payload) return NextResponse.json({ error: "Invalid token" }, { status: 401 });

    const patient = await Patient.findById(params.id);
    if (!patient) return NextResponse.json({ error: "Patient not found" }, { status: 404 });

    if (payload.role === "doctor" && !patient.assignedDoctorId.equals(payload.userId)) {
      return NextResponse.json({ error: "Access denied" }, { status: 403 });
    }

    return NextResponse.json({ success: true, patient });
  } catch (error) {
    console.error("[v0] Get patient error:", error);
    return NextResponse.json({ error: "Failed to fetch patient" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectDB();
    const token = request.headers.get("authorization")?.split(" ")[1];
    if (!token) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const payload = verifyToken(token);
    if (!payload) return NextResponse.json({ error: "Invalid token" }, { status: 401 });

    const patient = await Patient.findById(params.id);
    if (!patient) return NextResponse.json({ error: "Patient not found" }, { status: 404 });

    const updates = await request.json();

    if (payload.role === "doctor") {
      patient.medicalHistory = updates.medicalHistory || patient.medicalHistory;
      patient.allergies = updates.allergies || patient.allergies;
      patient.medicalConditions = updates.medicalConditions || patient.medicalConditions;
    } else {
      Object.assign(patient, updates);
      if (updates.assignedDoctorId) {
        patient.assignedDoctorId = new Types.ObjectId(updates.assignedDoctorId);
      }
    }

    await patient.save();
    return NextResponse.json({ success: true, patient });
  } catch (error) {
    console.error("[v0] Update patient error:", error);
    return NextResponse.json({ error: "Failed to update patient" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await context.params;
    await connectDB();

    const token = request.headers.get("authorization")?.split(" ")[1];
    if (!token) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const payload = verifyToken(token);
    if (!payload) return NextResponse.json({ error: "Invalid token" }, { status: 401 });

    if (payload.role !== "admin" && payload.role !== "receptionist") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 });
    }

    const deleted = await Patient.findByIdAndDelete(id);
    if (!deleted) return NextResponse.json({ error: "Patient not found" }, { status: 404 });

    return NextResponse.json({ success: true, message: "Patient deleted successfully" });
  } catch (error) {
    console.error("[v0] Delete patient error:", error);
    return NextResponse.json({ error: "Failed to delete patient" }, { status: 500 });
  }
}
