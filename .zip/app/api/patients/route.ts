import { NextRequest, NextResponse } from "next/server"
import { Patient, User, connectDB } from "@/lib/db"
import { verifyToken } from "@/lib/auth"
import { Types } from "mongoose"

export async function GET(request: NextRequest) {
  try {
    await connectDB()
    const token = request.headers.get("authorization")?.split(" ")[1]
    if (!token) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    const payload = verifyToken(token)
    if (!payload) return NextResponse.json({ error: "Invalid token" }, { status: 401 })

    const query: any = {}
    if (payload.role === "doctor") {
      query.assignedDoctorId = new Types.ObjectId(payload.userId)
    }

    const patients = await Patient.find(query).populate("assignedDoctorId", "name email")
    return NextResponse.json({ success: true, patients })
  } catch (error) {
    console.error("GET /api/patients error:", error)
    return NextResponse.json({ error: "Failed to fetch patients" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    await connectDB()
    const token = request.headers.get("authorization")?.split(" ")[1]
    if (!token) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    const payload = verifyToken(token)
    if (!payload) return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    if (payload.role === "doctor") return NextResponse.json({ error: "Doctors cannot add patients" }, { status: 403 })

    const {
      name,
      phone,
      email,
      dob,
      insuranceProvider,
      allergies = [],
      medicalConditions = [],
      assignedDoctorId,
    } = await request.json()

    const missingCredentials = []
    if (!phone) missingCredentials.push("Phone")
    if (!email) missingCredentials.push("Email")
    if (!dob) missingCredentials.push("Date of Birth")
    if (!insuranceProvider) missingCredentials.push("Insurance Provider")

    const doctor = assignedDoctorId ? await User.findById(assignedDoctorId) : null

    const newPatient = await Patient.create({
      name,
      phone,
      email,
      dob,
      insuranceProvider,
      allergies,
      medicalConditions,
      status: "active",
      balance: 0,
      assignedDoctorId: doctor?._id || null,
      doctorHistory: doctor
        ? [{ doctorId: doctor._id, doctorName: doctor.name, startDate: new Date() }]
        : [],
      medicalHistory: "",
      credentialStatus: missingCredentials.length === 0 ? "complete" : "incomplete",
      missingCredentials,
    })

    return NextResponse.json({ success: true, patient: newPatient })
  } catch (error) {
    console.error("POST /api/patients error:", error)
    return NextResponse.json({ error: "Failed to add patient" }, { status: 500 })
  }
}
